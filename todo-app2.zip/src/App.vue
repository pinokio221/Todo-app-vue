<template>
  <div id="app">
    <todo></todo>
  </div>
</template>

<script>
import todo from './components/todo'

export default {
  name: 'App',
  components: {
    todo
  }
}

</script>

<style>

</style>
